# Matriz de pruebas Android — OrtoGestión Pro 2.1

| ID | Área | Prueba | Resultado esperado | Estado |
|---|---|---|---|---|
| A01 | Instalación | Instalar APK debug en API 26+ | Instala y abre sin crash | Pendiente SDK/dispositivo |
| A02 | Arranque | Primer inicio y aviso legal | Aviso propio visible; continuar requiere aceptación | Pendiente dispositivo |
| A03 | Modales | Validar mensajes/confirmaciones/entradas | Solo modal de la app; cero alert/confirm/prompt JS | Estático: 0 llamadas directas |
| A04 | Sesión | Alta inicial, login, logout | Sesión y roles correctos | Pendiente dispositivo |
| A05 | Persistencia | Crear paciente, cerrar forzado y reabrir | Registro permanece íntegro | Pendiente dispositivo |
| A06 | Cifrado | Verificar desbloqueo y clave errónea | Error controlado; datos no sobrescritos | Pendiente dispositivo |
| A07 | Clínico | Registrar mediciones cefalométricas y dental | Validaciones, unidades y trazabilidad | Pendiente validación clínica |
| A08 | Imágenes | Importar JPG/PNG desde selector | Imagen asociada al paciente y visible | Pendiente dispositivo |
| A09 | Respaldo | Exportar `.ogbackup` cifrado | Selector de destino y archivo íntegro | Pendiente dispositivo |
| A10 | Restauración | Importar respaldo válido y contraseña incorrecta | Restauración válida; error sin alterar datos | Pendiente dispositivo |
| A11 | Seguridad | Intentar HTTP, ventanas emergentes y permisos | Bloqueo de navegación/permisos no requeridos | Revisión estática; runtime pendiente |
| A12 | Ciclo de vida | Rotar, suspender, reanudar y reiniciar | Estado consistente y sesión protegida | Pendiente dispositivo |
| A13 | Rendimiento | 100 pacientes y 500 imágenes sintéticas | Sin bloqueo prolongado ni pérdida | Pendiente dispositivo |
| A14 | Accesibilidad | Teclado, foco y tamaño de controles | Controles utilizables en pantalla pequeña | Pendiente dispositivo |
