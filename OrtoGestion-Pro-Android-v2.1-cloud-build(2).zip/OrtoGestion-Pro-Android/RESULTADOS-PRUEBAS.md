# Resultados de verificación — OrtoGestión Pro Android 2.1

Fecha de ejecución: 2026-11-24.

## Pruebas ejecutadas correctamente

| Prueba | Resultado |
|---|---|
| Sintaxis JavaScript del HTML completo (`node --check`) | PASS |
| Auditoría estática de `alert()`, `confirm()`, `prompt()` | PASS — 0 llamadas directas |
| Elemento HTML `<dialog>` | PASS — 0 elementos |
| Modal propio: alerta, confirmación aceptar/cancelar y prompt | PASS |
| Entrada de contraseña enmascarada en prompt | PASS |
| Cola de diálogos simultáneos | PASS |
| Texto de diálogo insertado con `textContent` (no interpreta HTML) | PASS |
| Interpolación Moyers: límites, interpolación y percentil no admitido | PASS (prueba de la implementación, no validación clínica de la tabla) |
| Edad cronológica en fecha de cumpleaños y día anterior | PASS |
| Clasificación matemática de puntuación Z en umbrales | PASS |
| CSP presente y bloqueo de frames/Workers | PASS estático |

Para repetir: ejecutar `tests/run-tests.sh` con Node.js.

## Pruebas no ejecutadas / bloqueadas por el entorno

- Compilación APK: no se ejecutó porque este entorno no tiene Android SDK ni Gradle instalados. Java sí está disponible.
- Instalación y ejecución en emulador o teléfono: no disponible aquí.
- Se intentó una prueba de carga en Chromium headless, pero el navegador no llegó a devolver el DOM y quedó bloqueado en el entorno; no se contabiliza como prueba funcional superada.
- Persistencia IndexedDB real, restauración cifrada con selector Android, imágenes, rotación, ciclo de vida, rendimiento y bloqueo de capturas: requieren emulador/dispositivo.
- No se han validado clínicamente las normas cefalométricas, Moyers, Bolton, PAR/ABO ni la idoneidad diagnóstica de sus salidas. Las pruebas de helpers solo comprueban comportamiento matemático de funciones concretas.

## Estado

**Proyecto Android fuente preparado; APK todavía no compilada ni validada en dispositivo.** No debe instalarse como versión clínica ni utilizarse con pacientes reales hasta completar las pruebas Android, revisión clínica y validación regulatoria aplicable.
