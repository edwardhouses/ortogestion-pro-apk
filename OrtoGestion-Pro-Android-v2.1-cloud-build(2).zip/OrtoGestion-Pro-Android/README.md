# OrtoGestión Pro — proyecto Android 2.1

Este proyecto empaqueta la aplicación local dentro de Android WebView mediante `WebViewAssetLoader` y el origen HTTPS seguro `appassets.androidplatform.net`. No utiliza `file://` ni habilita acceso universal desde archivos.

## Requisitos
- Android Studio reciente (AGP 8.7.3 compatible).
- JDK 17 o superior.
- Android SDK Platform 35 y Build Tools instalados.
- Conexión a Internet durante la primera sincronización Gradle y para la activación de licencia Supabase.

## Estado de esta entrega

Se entrega el proyecto fuente Android, la aplicación HTML adaptada y pruebas automatizadas locales. **Todavía no se incluye un APK**: el entorno de preparación no dispone de Android SDK ni Gradle. Consulta `RESULTADOS-PRUEBAS.md` para separar las pruebas ejecutadas de las que requieren un teléfono/emulador.

## Abrir y compilar
1. Abrir esta carpeta en Android Studio.
2. Esperar a que Gradle sincronice y descargue las dependencias.
3. Ejecutar `app` en un dispositivo/emulador Android 8.0 (API 26) o superior.
4. Para APK de pruebas: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. El APK debug se genera en `app/build/outputs/apk/debug/`.

No se incluye una clave de firma de producción. Para distribuir un APK release, el propietario debe crear y custodiar su propia clave de firma.

## Decisiones de seguridad
- WebView carga exclusivamente el contenido local mediante WebViewAssetLoader.
- JavaScript y DOM Storage habilitados porque son necesarios para la aplicación.
- Acceso `file://`, ventanas emergentes, contenido mixto y cleartext HTTP deshabilitados.
- Recursos remotos bloqueados salvo el endpoint Supabase de activación/licencia.
- Se deniegan permisos de cámara/micrófono/geolocalización.
- Capturas de pantalla y vista previa de recientes protegidas con `FLAG_SECURE`.
- El único puente JavaScript está limitado a guardar un archivo Blob tras una acción de exportación; valida nombre y tamaño y usa el selector de destino del sistema.
- La selección de imágenes usa el selector de documentos del sistema por petición explícita del usuario.

## Limitaciones pendientes de validar en dispositivo
- Persistencia real de IndexedDB tras forzar cierre, reiniciar y actualizar la app.
- Cuota y rendimiento con bibliotecas grandes de imágenes clínicas.
- Importación de respaldos cifrados y exportación mediante el selector de destino.
- Comportamiento de activación cuando no hay conexión.
- Teclado, rotación, modo multitarea, bloqueo y reanudación.
- Pruebas en dispositivos Android físicos de distintas versiones y fabricantes.

## Seguridad clínica
Los datos incluidos para pruebas deben ser ficticios. Esta compilación no constituye aprobación para uso clínico real ni certificación SaMD. Las tablas y algoritmos clínicos requieren validación bibliográfica y clínica independiente antes de usarse para decisiones asistenciales.
