const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/assets/www/index.html'), 'utf8');
const block = html.match(/\/\* Modal accesible, propio y asíncrono[\s\S]*?function showAppAlert\([\s\S]*?\n}/);
assert.ok(block, 'modal manager exists');
class Element {
  constructor(){this.hidden=false;this.value='';this.type='text';this.placeholder='';this.textContent='';this.style={};this.listeners={};this.attrs={};}
  addEventListener(k,fn){(this.listeners[k]??=[]).push(fn)}
  removeEventListener(k,fn){this.listeners[k]=(this.listeners[k]||[]).filter(x=>x!==fn)}
  setAttribute(k,v){this.attrs[k]=v}
  focus(){if(this._doc)this._doc.activeElement=this}
  click(){for(const f of [...(this.listeners.click||[])])f({})}
}
const els={};for(const id of ['appDialogModal','appDialogTitle','appDialogMessage','appDialogInput','appDialogCancel','appDialogOk'])els[id]=new Element();
const document={body:{style:{}},activeElement:new Element(),getElementById:id=>els[id]};for(const el of Object.values(els))el._doc=document;
const context={document,Promise,String};vm.createContext(context);vm.runInContext(block[0],context);
(async()=>{
  let p=context.showAppAlert('Texto de prueba <script>');await Promise.resolve();
  assert.equal(els.appDialogModal.hidden,false);assert.equal(els.appDialogMessage.textContent,'Texto de prueba <script>');assert.equal(els.appDialogCancel.hidden,true);els.appDialogOk.click();assert.equal(await p,true);
  p=context.showAppDialog({type:'confirm',message:'¿Eliminar?'});await Promise.resolve();els.appDialogCancel.click();assert.equal(await p,null);
  p=context.showAppDialog({type:'confirm',message:'¿Guardar?'});await Promise.resolve();els.appDialogOk.click();assert.equal(await p,true);
  p=context.showAppDialog({type:'prompt',message:'Clave',inputType:'password'});await Promise.resolve();assert.equal(els.appDialogInput.type,'password');els.appDialogInput.value='secreto';els.appDialogOk.click();assert.equal(await p,'secreto');
  const p1=context.showAppDialog({type:'alert',message:'primero'});const p2=context.showAppDialog({type:'alert',message:'segundo'});await Promise.resolve();assert.equal(els.appDialogMessage.textContent,'primero');els.appDialogOk.click();await p1;await Promise.resolve();assert.equal(els.appDialogMessage.textContent,'segundo');els.appDialogOk.click();await p2;
  console.log('PASS: alert, confirm cancel/accept, password prompt, queued dialogs, textContent escaping');
})().catch(e=>{console.error(e);process.exitCode=1});
