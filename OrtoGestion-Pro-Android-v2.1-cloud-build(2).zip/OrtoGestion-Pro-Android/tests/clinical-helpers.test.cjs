const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/assets/www/index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/i)[1];
const parts = [];
for (const name of ['ageOnDate','classifyZ']) {
  const re = name === 'ageOnDate' ? /function ageOnDate\([\s\S]*?\n}/ : /function classifyZ\([\s\S]*?\n}/;
  const m = script.match(re); assert.ok(m, name+' exists'); parts.push(m[0]);
}
const ctx={Date,Math};vm.createContext(ctx);vm.runInContext(parts.join('\n'),ctx);
assert.equal(ctx.ageOnDate('2010-11-24','2026-11-23'),15);
assert.equal(ctx.ageOnDate('2010-11-24','2026-11-24'),16);
assert.equal(ctx.ageOnDate('2010-02-28','2026-02-27'),15);
assert.equal(ctx.ageOnDate('', '2026-01-01'),null);
assert.equal(ctx.classifyZ(82,82,2,2).nivel,'normal');
assert.equal(ctx.classifyZ(84.1,82,2,2).nivel,'vigilar');
assert.equal(ctx.classifyZ(86.1,82,2,2).nivel,'fuera');
console.log('PASS: age calculation boundaries and z-score classification');
