#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
node -e "const fs=require('fs');const s=fs.readFileSync('app/src/main/assets/www/index.html','utf8');const m=s.match(/<script>([\s\S]*?)<\/script>/i);if(!m)process.exit(2);fs.writeFileSync('/tmp/ortogestion-inline-check.js',m[1]);"
node --check /tmp/ortogestion-inline-check.js
node tests/static-audit.test.cjs
node tests/modal.test.cjs
node tests/moyers.test.cjs
node tests/clinical-helpers.test.cjs
