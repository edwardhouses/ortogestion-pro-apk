# No se expone un puente JavaScript general. Mantener solo el método de exportación explícito.
-keepclassmembers class com.ortogestion.pro.MainActivity$DownloadBridge {
    @android.webkit.JavascriptInterface <methods>;
}
