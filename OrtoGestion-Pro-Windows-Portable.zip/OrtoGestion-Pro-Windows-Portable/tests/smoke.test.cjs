const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "www", "index.html"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));

assert.ok(html.includes("<!DOCTYPE html>"), "Debe existir el HTML principal");
assert.ok(html.includes("OrtoGestión Pro"), "El HTML debe ser la aplicación OrtoGestión Pro");
assert.equal(pkg.build.win.target[0].target, "portable", "La salida debe ser portátil");
assert.match(main, /nodeIntegration:\s*false/);
assert.match(main, /contextIsolation:\s*true/);
assert.match(main, /sandbox:\s*true/);
assert.match(main, /ortogestion:\/\/app\/index\.html/);
console.log("Pruebas de estructura Windows: OK");
