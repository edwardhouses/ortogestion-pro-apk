# OrtoGestión Pro 2.1 — Windows portátil

Este proyecto prepara una compilación Windows x64 en formato **portable `.exe`** mediante GitHub Actions. No instala la aplicación ni requiere Android Studio.

## Compilar desde GitHub usando el teléfono

1. Sube `OrtoGestion-Pro-Windows-Portable.zip` a la raíz del mismo repositorio GitHub donde compilaste la APK.
2. Crea el archivo `.github/workflows/windows-portable.yml` y pega el workflow incluido en este proyecto (también puedes copiarlo desde la carpeta `.github/workflows/`).
3. En GitHub abre **Actions** → **Build OrtoGestion Pro Windows Portable EXE**.
4. Pulsa **Run workflow** y espera la marca verde.
5. Abre la ejecución y descarga el artefacto `OrtoGestion-Pro-2.1-Windows-Portable`.
6. Extrae el ZIP del artefacto en Windows y ejecuta `OrtoGestion-Pro-2.1-portable-x64.exe`.

## Datos y uso

- La aplicación carga el HTML local dentro de Electron.
- La persistencia del navegador se guarda en el perfil local de Electron en el equipo Windows. El `.exe` portátil no significa que los datos viajen automáticamente con el ejecutable.
- La validación de licencia puede necesitar conexión a Internet, según la lógica incluida en la aplicación.
- No se ha verificado todavía el funcionamiento en un equipo Windows real. Las pruebas del workflow son pruebas estructurales y de compilación, no una validación clínica ni una prueba integral de todas las funciones.
- Antes de usar datos reales, probar creación/edición de pacientes, imágenes, importación/exportación, cierre y reapertura, y copias de seguridad. Usar únicamente datos ficticios durante las pruebas.

## Requisitos

- Windows 10/11 de 64 bits para ejecutar este artefacto.
- El ejecutable puede mostrar advertencia de SmartScreen porque no está firmado digitalmente.
